
 int count1=0,count2=0,left=0,right=0;
 int mode=0,i,j;
  #define red1 portd.b2
  #define green1 portd.b0
  #define yellow1 portd.b1
  #define red2 portd.b5
  #define yellow2 portd.b4
  #define green2 portd.b3
  #define switch1 portb.ra0
  #define switch2 portb.ra1

  void segment1(int count);
  void segment2(int count);
  void manual();
  
  void interrupt(){
    if(intf_bit==1){
   intf_bit=0;
   while(1){
   manual();}

    }
   }

void main() {
       trisb=0b00000001;
       portb=0;
       trisc=0x00;
       portc=0x00;
       trisa=0b00000011;
       trisd=0x00;
       portd=0;
       trise=0x00 ;
       porte=0X00000011 ;
       gie_bit=1;
       inte_bit=1;
       intedg_bit=1;
       
       

       adcon1=7;

       while(1){

       if(switch1==1 ){

       if(mode==0)mode=1; //change the previous mode
       
       else mode=0;
       }

       if(mode== 0){
         segment1(count1);
         count1++;
         count2++;


         for( i =15 ;i>=0;i--){
                 yellow1=0;
                 green1=0;
                 red1=255;
                 red2=0;
                 if(i<=3){
                       yellow2=255;
                       green2=0;
                       }

                 else{green2=255;
                      yellow2=0;}
         for(j=0;j<=100;j++){
                  segment1(i);
                            }
                            }
         for( i=23;i>=0;i--){
              red2=255;
              yellow2=0;
              green2=0 ;
              red1=0;
              if(i<=3){
                 yellow1=255;
                 green1=0;
                 }
              else {
                 yellow1=0;
                 green1=255;
                 }

              for(j=0;j<=100;j++){
                 segment1(i);
                }
                
                }




       }
         }
}
void segment1(int count){
   left = count / 10;
    right = count % 10;
    PORTE.B0 = 1;
    PORTE.B1 = 0;

    PORTC =left;
    delay_ms(10);
    PORTE.B0 = 0;
    PORTE.B1 = 1;
    PORTC = right;

    delay_ms(10);


   }
   void segment2(int count){
   left = count / 10;
    right = count % 10;
    PORTE.B0 = 1;
    PORTE.B1 = 0;

    PORTC =left;
    delay_ms(10);
    PORTE.B0 = 0;
    PORTE.B1 = 1;
    PORTC = right;

    delay_ms(10);


   }
void manual(){
       segment2(0);
       portd=0;


       while(1){


       while(switch2==0) ; // wait until the button is pushed
         portd=0;
         yellow1=255;
         red2=255;
         for( i =3 ;i>=0;i--){ 
         for(j=0;j<=100;j++){
             segment2(i);}
             
             }

         portd=0;
         green1=255;
         red2=255 ;


       while(switch2==0) ;  // wait until the button is pushed
         portd=0;
         yellow2=255;
         red1=255;
       for( i =3 ;i>=0;i--){
          for(j=0;j<=100;j++){
          segment2(i);}}
          portd=0;
          red1=255;
          green2=255;

        }
       }